/* Service worker: gemmer hele appen til offline brug. Genereres af build – rediger assets/sw.js. */
'use strict';
const VERSION = '1.0.0-4ebe0141a82d';
const PRECACHE = [
  "./",
  "grundteknikker/",
  "grundteknikker/stokteknik/",
  "grundteknikker/diagonal-teknik/",
  "grundteknikker/ledsageteknik/",
  "faerden-i-trafik/",
  "faerden-i-trafik/krydsning/",
  "faerden-i-trafik/lysregulerede-kryds/",
  "faerden-i-trafik/offentlig-transport/",
  "faerden-i-trafik/offentlig-transport/bus/",
  "om-appen/",
  "soeg/",
  "installer/",
  "manifest.webmanifest",
  "search-index.json",
  "assets/style.css",
  "assets/app.js",
  "icons/apple-touch-icon.png",
  "icons/favicon-32.png",
  "icons/favicon.svg",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "icons/icon-maskable-512.png",
  "media/diagonal-teknik-01-f7755e8ef9-1280.webp",
  "media/diagonal-teknik-01-f7755e8ef9-640.webp",
  "media/forside-46615dbd52-1280.webp",
  "media/forside-46615dbd52-640.webp",
  "media/krydsning-01-4ed5e48b15-1280.webp",
  "media/krydsning-01-4ed5e48b15-640.webp",
  "media/ledsageteknik-01-ee1c9b080d-1280.webp",
  "media/ledsageteknik-01-ee1c9b080d-640.webp",
  "media/lyskryds-01-6125fe99d4-1280.webp",
  "media/lyskryds-01-6125fe99d4-640.webp",
  "media/stokteknik-01-ab6eba49fb-1280.webp",
  "media/stokteknik-01-ab6eba49fb-640.webp"
];
const SCOPE = self.registration.scope; // fx https://eksempel.dk/om-teknik/
const PREFIX = 'mdpwa:' + new URL(SCOPE).pathname + ':';
const CACHE = PREFIX + VERSION;

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    // cache: 'reload' går uden om browserens HTTP-cache, så vi får den nye version.
    await cache.addAll(PRECACHE.map((p) => new Request(new URL(p, SCOPE), { cache: 'reload' })));
  })());
  // Første installation aktiveres straks. Opdateringer venter, til brugeren vælger "Genindlæs".
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) {
      if (key.startsWith(PREFIX) && key !== CACHE) await caches.delete(key);
    }
    await self.clients.claim();
  })());
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
  if (event.data && event.data.type === 'GET_VERSION' && event.source) event.source.postMessage({ type: 'VERSION', version: VERSION });
});

function normalize(url) {
  const u = new URL(url);
  u.search = '';
  u.hash = '';
  if (u.pathname.endsWith('/index.html')) u.pathname = u.pathname.slice(0, -10);
  return u.href;
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET' || !req.url.startsWith(SCOPE)) return;
  const isNav = req.mode === 'navigate';

  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const key = isNav ? normalize(req.url) : req.url;
    let hit = await cache.match(key, { ignoreSearch: isNav });
    if (!hit && isNav && !key.endsWith('/')) hit = await cache.match(key + '/');
    if (hit) return hit;
    try {
      const res = await fetch(req);
      // Ting der ikke var forhåndsgemt (fx JPEG-fallback), gemmes når de hentes.
      if (res.ok && !isNav && res.type === 'basic') cache.put(req, res.clone());
      return res;
    } catch (err) {
      if (isNav) {
        return new Response(
          '<!doctype html><html lang="da"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
          + '<title>Ingen forbindelse</title><main style="font-family:system-ui;padding:1rem;max-width:40rem">'
          + '<h1>Siden findes ikke offline</h1><p>Du er uden internet, og denne side er ikke gemt i appen.</p>'
          + '<p><a href="' + SCOPE + '">Gå til forsiden</a></p></main></html>',
          { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8' } }
        );
      }
      throw err;
    }
  })());
});
